﻿using System;
namespace Quiz2
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Food food1 = new Food();
            food1.FoodQuestion();

            Console.WriteLine("\nSelect your meal (C - Chicken, P - Pizza, S - Spagetti, T- Steak");
            food1.Menu = Convert.ToChar(Console.ReadLine());

            Console.WriteLine("\nHow many people in your party?: ");
            food1.Qty = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\nWould you like to try out Baldi's Homemade Cheesecake for $10 per party?: ");
            food1.Cheesecake = Convert.ToChar(Console.ReadLine());

            food1.TOTAL1(food1.Menu, food1.Qty, food1.Cheesecake);
            food1.FoodResponse(food1.Menu, food1.Qty, food1.Cheesecake);
        }
    }
}