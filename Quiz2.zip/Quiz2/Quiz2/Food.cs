﻿using System;
namespace Quiz2
{
    public class Food
    {
        public char Menu
        {
            get;
            set;
        }
        public int Qty
        {
            get;
            set;
        }
        public char Cheesecake
        {
            get;
            set;
        }
        public double Total
        {
            get;
            set;
        }
        public void FoodQuestion()
        {
            Console.WriteLine("-------------Welcome to Baldi's Kitchen-------------");
            Console.WriteLine("Chicken         Pizza           Spagetti       Steak");
            Console.WriteLine("$20.00          $25.00          $15.00         $35.00");
        }
        public double TOTAL1(char Menu, int Qty, char Cheesecake)
        {
            if (Menu == 'C')
            {
                double chicken = 20.00;
                double menu2 = chicken * Qty;
                if (Cheesecake == 'Y')
                {
                    double cake = 10.00;
                    double menu3 = cake * Qty;
                    return Total = menu2 + menu3;
                }
                else
                {
                    return Total = menu2;
                }
            }
            else if (Menu == 'P')
            {
                double pizza = 25.00;
                double menu2 = pizza * Qty;
                if (Cheesecake == 'Y')
                {
                    double cake = 10.00;
                    double menu3 = cake * Qty;
                    return Total = menu2 + menu3;
                }
                else
                {
                    return Total = menu2;
                }

            }
            else if (Menu == 'S')
            {
                double spagetti = 15.00;
                double menu2 = spagetti * Qty;
                if (Cheesecake == 'Y')
                {
                    double cake = 10.00;
                    double menu3 = cake * Qty;
                    return Total = menu2 + menu3;
                }
                else
                {
                    return Total = menu2;
                }
            }
            else
            {
                double steak = 35.00;
                double menu2 = steak * Qty;
                if (Cheesecake == 'Y')
                {
                    double cake = 10.00;
                    double menu3 = cake * Qty;
                    return Total = menu2 + menu3;
                }
                else
                {
                    return Total = menu2;
                }
            }
        }
        public void FoodResponse(char Menu, int Qty, char Cheesecake)
        {
            Console.WriteLine("\nYour total is: " + Total);
            Console.WriteLine("Your order was " + Menu + ", for the party of " + Qty + ". \nCheesecake Included: " + Cheesecake);
        }
    }
}